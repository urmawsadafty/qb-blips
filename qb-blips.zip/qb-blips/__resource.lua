description 'GTA V Blips'

client_script 'blips.lua'

--Made By Dafty